package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

// Handle key inputs for game character
public class KeyHandler implements KeyListener{
	
	public String letPressed;
	public boolean hasPressed;
	public boolean nameEntered = false;
	public boolean deleteLast;
	
	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {

		int code = e.getKeyCode(); // getKeyCode returns integer representation of key pressed
		
		if(code == KeyEvent.VK_A)
		{ letPressed = "A"; hasPressed = true; }
		
		if(code == KeyEvent.VK_B)
		{ letPressed = "B"; hasPressed = true; }
		
		if(code == KeyEvent.VK_C)
		{ letPressed = "C"; hasPressed = true; }
		
		if(code == KeyEvent.VK_D)
		{ letPressed = "D"; hasPressed = true; }
		
		if(code == KeyEvent.VK_E)
		{ letPressed = "E"; hasPressed = true; }
		
		if(code == KeyEvent.VK_F)
		{ letPressed = "F"; hasPressed = true; }
		
		if(code == KeyEvent.VK_G)
		{ letPressed = "G"; hasPressed = true; }
		
		if(code == KeyEvent.VK_H)
		{ letPressed = "H"; hasPressed = true; }
		
		if(code == KeyEvent.VK_I)
		{ letPressed = "I"; hasPressed = true; }
		
		if(code == KeyEvent.VK_J)
		{ letPressed = "J"; hasPressed = true; }
		
		if(code == KeyEvent.VK_K)
		{ letPressed = "K"; hasPressed = true; }
		
		if(code == KeyEvent.VK_L)
		{ letPressed = "L"; hasPressed = true; }
		
		if(code == KeyEvent.VK_M)
		{ letPressed = "M"; hasPressed = true; }
		
		if(code == KeyEvent.VK_N)
		{ letPressed = "N"; hasPressed = true; }
		
		if(code == KeyEvent.VK_O)
		{ letPressed = "O"; hasPressed = true; }
		
		if(code == KeyEvent.VK_P)
		{ letPressed = "P"; hasPressed = true; }
		
		if(code == KeyEvent.VK_Q)
		{ letPressed = "Q"; hasPressed = true; }
		
		if(code == KeyEvent.VK_R)
		{ letPressed = "R"; hasPressed = true; }
		
		if(code == KeyEvent.VK_S)
		{ letPressed = "S"; hasPressed = true; }
		
		if(code == KeyEvent.VK_T)
		{ letPressed = "T"; hasPressed = true; }
		
		if(code == KeyEvent.VK_U)
		{ letPressed = "U"; hasPressed = true; }
		
		if(code == KeyEvent.VK_V)
		{ letPressed = "V"; hasPressed = true; }
		
		if(code == KeyEvent.VK_W)
		{ letPressed = "W"; hasPressed = true; }
		
		if(code == KeyEvent.VK_X)
		{ letPressed = "X"; hasPressed = true; }
		
		if(code == KeyEvent.VK_Y)
		{ letPressed = "Y"; hasPressed = true; }
		
		if(code == KeyEvent.VK_Z)
		{ letPressed = "Z"; hasPressed = true; }
		
		if(code == KeyEvent.VK_SPACE)
		{ letPressed = " "; hasPressed = true; }
		
		if(code == KeyEvent.VK_BACK_SPACE)
		{ letPressed = ""; hasPressed = true; deleteLast = true; }
		
		if(code == KeyEvent.VK_ENTER)
		{ letPressed = ""; hasPressed = true; nameEntered = true; }
	}

	@Override
	public void keyReleased(KeyEvent e) {

//		int code = e.getKeyCode(); // getKeyCode returns integer representation of key pressed
//		
//		if(code == KeyEvent.VK_W || code == KeyEvent.VK_UP)
//		{ upPressed = false; }
//		
//		if(code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT)
//		{ leftPressed = false; }
//		
//		if(code == KeyEvent.VK_S || code == KeyEvent.VK_DOWN)
//		{ downPressed = false; }
//		
//		if(code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT)
//		{ rightPressed = false; }
//		
//		if(code == KeyEvent.VK_R)
//		{ isRunning = false; }
	}

/*	public KeyHandler() {
		// TODO Auto-generated constructor stub
	}
*/
	
}
