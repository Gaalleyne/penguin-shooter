package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.awt.MouseInfo;

import javax.imageio.ImageIO;

import components.GameButton;
import main.GamePanel.STATE;

public class Menu {
	
	GamePanel gp;
	private GameButton newGameBtn;
	private GameButton leaderboardsBtn;
	private GameButton quitBtn;
	private Image[] menuVisuals = new Image[10];
	
	public Menu(GamePanel gp) 
	{
		this.gp = gp;
		getImages();
	}
	
	public void getImages()
	{
		try
		{
			menuVisuals[0] = ImageIO.read(getClass().getResourceAsStream("/titleArt/iceForeground.png"));
			menuVisuals[1] = ImageIO.read(getClass().getResourceAsStream("/titleArt/iceBorder.png"));
		}
		catch(IOException e) { e.printStackTrace(); }
	}
	
	public void draw(Graphics2D g2)
	{
		Font titleFont = new Font("Bodoni MT Poster Compressed", Font.BOLD, 65);
		
		//g2.setColor(new Color(247, 220, 180));
		//g2.fillRect(gp.screenWidth/12, 75, 375, 100);
		g2.drawImage(menuVisuals[1], gp.screenWidth/19, 25, 400, 125, null);
		g2.drawImage(menuVisuals[0], gp.screenWidth/12, 35, 375, 100, null);
		
		g2.setFont(titleFont);
		g2.setColor(Color.BLACK);
		g2.drawString("PENGUIN SHOOTER", gp.screenWidth/7, 110);
		
		newGameBtn = new GameButton(menuVisuals[0], menuVisuals[1], 200, 75, 110, 200, g2, 
								"New Game", new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		newGameBtn.drawButton(g2, 135, 255);
		
		leaderboardsBtn = new GameButton(menuVisuals[0], menuVisuals[1], 200, 75,
				110, 325, g2, "Scoreboard",
				new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		leaderboardsBtn.drawButton(g2, 122, 380);
		
		quitBtn = new GameButton(menuVisuals[0], menuVisuals[1], 200, 75,
				110, 450, g2, "Quit",
				new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		quitBtn.drawButton(g2, 175, 510);
		
		readMouseData(g2);
	}

	public void readMouseData(Graphics2D g2) {
		
		if(newGameBtn.mouseIsOver())
		{  newGameBtn.highlightBtn(g2); }
		
		if(leaderboardsBtn.mouseIsOver())
		{  leaderboardsBtn.highlightBtn(g2); }
		
		if(quitBtn.mouseIsOver())
		{  quitBtn.highlightBtn(g2); }
		
		gp.addMouseListener(new MouseAdapter()
		{
			public void mouseClicked(MouseEvent e)
			{
					if(newGameBtn.mouseIsOver())
					{  
						gp.State = STATE.GAME_START; 
						gp.gameIntro = new GameIntro(gp, gp.kH);
						gp.removeMouseListener(this); 
					}
					
					if(leaderboardsBtn.mouseIsOver())
					{  
						gp.State = STATE.LEADERBOARDS; 
						gp.leaderboards = new Leaderboards(gp);
						gp.removeMouseListener(this);
					}
					
					if(quitBtn.mouseIsOver())
					{  System.exit(0); }
				
			}
		});
	}
}
