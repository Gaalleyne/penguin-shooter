package main;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Scanner;

import main.GamePanel.STATE;

public class GameIntro {

	GamePanel gp;
	Leaderboards leaderboards;
	KeyHandler kH;
	
	String userName;
	int countdown;
	
	public GameIntro(GamePanel gp, KeyHandler kH) {
		
		this.gp = gp;
		this.kH = kH;
		leaderboards = new Leaderboards();
		userName = "";
	}
	
	public void draw(Graphics2D g2)
	{
		gp.setBackground(Color.BLACK);
		
		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		
		
		g2.drawString("ENTER YOUR NAME: ", 60, 100);
		
		g2.drawLine(0, 250, 448, 250);
		g2.drawLine(0, 305, 448, 305);
		if(kH.hasPressed == true)
		{
			if(kH.deleteLast == true) 
			{
				userName = userName.substring(0, userName.length() - 1); 
				kH.deleteLast = false; 
			}
			else
			{userName += kH.letPressed;}
			
			kH.hasPressed = false;
		}
		
		if(!kH.nameEntered)
		{ g2.drawString(userName, 30, 300); }
		else
		{ 
			countdown(g2); 
		}
	}

	private void countdown(Graphics2D g2) {
		
		if(gp.countdown <= 60) { g2.drawString("3...", 200, 300); }
		else if(gp.countdown <= 120) { g2.drawString("2...", 200, 300); }
		else if(gp.countdown <= 180) { g2.drawString("1...", 200, 300); }
		else if(gp.countdown <= 240) { g2.drawString("BEGIN!", 170, 300); }
		else 
		{ 
			gp.countdown = 0; 
			gp.State = STATE.GAME;
			gp.gameLoop = new GameLoop(gp); 
			kH.nameEntered = false; 
			
			leaderboards.addName(userName);
			leaderboards.updateNamesAndScores();
		}
		
	}

}
