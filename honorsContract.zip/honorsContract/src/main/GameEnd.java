package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import main.GamePanel.STATE;

public class GameEnd {

	GamePanel gp;
	GameLoop gameLoop;
	
	public GameEnd(GamePanel gp, GameLoop gameLoop) 
	{
		this.gp = gp;
		this.gameLoop = gameLoop;
	}

	public void draw(Graphics2D g2) {
		gp.setBackground(Color.BLACK);
		
		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		
		if(gp.countdown < 180) { g2.drawString("GAME END", 140, 300); }
		
		else
		{ 
			g2.drawString("REGULAR PENGUINS HIT: " + gameLoop.regPenguinsHit, 25, 100);
			if(gp.countdown > 240 ) { g2.drawString("SPECIAL PENGUINS HIT: " + gameLoop.specialPenguinsHit, 25, 150); }
			if(gp.countdown > 300 ) { g2.drawString("SHOTS MISSED: " + gameLoop.shotsMissed, 25, 205); }
			if(gp.countdown > 360 ) { g2.drawString("--------------------------", 25, 245); }
			if(gp.countdown > 420 ) { g2.drawString("SCORE: " + gameLoop.score, 25, 285); }
			if(gp.countdown > 480 ) 
			{ 
				g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 95));
				g2.drawString("MENU", 125, 525); 
			}
		}
		
		gp.addMouseListener(gp.endMouse = new MouseAdapter()
		{
			public void mouseReleased(MouseEvent e2)
			{
				if(gp.State == STATE.GAME_END && gp.countdown > 400) 
				{ 
					gp.leaderboards = new Leaderboards(gp);
					gp.State = STATE.MENU; 
					gp.countdown = 0; 
				}
			}
		});
	}
}
