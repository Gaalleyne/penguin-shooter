package main;

import javax.swing.JFrame;

public class PenguinShooterRunner {

	public static void main(String[] args) {
		
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setTitle("Penguin Shooter");
		
		GamePanel game_panel = new GamePanel();
		window.add(game_panel);
		
		window.pack();
		
		window.setLocation(400, 25);
		window.setVisible(true);
		
		game_panel.startGameThread();

	}

}
