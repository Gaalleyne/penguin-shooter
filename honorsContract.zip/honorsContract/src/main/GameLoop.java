package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.imageio.ImageIO;

import entities.Penguin;
import entities.Reticle;
import entities.SpecialPenguin;
import main.GamePanel.STATE;

public class GameLoop {
	
	GamePanel gp;
	Leaderboards leaderboards;
	
	Penguin[] penguinsOnScreen;
	Reticle reticle;
	
	int penguinsToSpawn;
	int penguinCounter;
	int sideScrollX;
	int ammoLeft;
	int reload;
	int clickBuffer;
	int spawnTickCount;
	int spawnInterval;
	int score;
	
	int regPenguinsHit;
	int specialPenguinsHit;
	int shotsMissed;
	
	Boolean shotTaken;
	Image[] gameVisuals = new Image[10];
	
	public GameLoop(GamePanel gp) 
	{
		this.gp = gp;
		leaderboards = new Leaderboards();
		
		score = 0;
		reticle = new Reticle(gp);
		penguinsToSpawn = 0;
		penguinsOnScreen = new Penguin[3];
		penguinCounter = 0;
		spawnTickCount = 0;
		spawnInterval = (int)(Math.random() * 240) + 30;
		
		sideScrollX = 0;
		
		ammoLeft = 3;
		reload = 0;
		clickBuffer = 0;
		shotTaken = false;
		
		regPenguinsHit = 0;
		specialPenguinsHit = 0;
		shotsMissed = 0;
		
		getImages();
	}
	
	public void getImages()
	{
		try
		{
			gameVisuals[0] = ImageIO.read(getClass().getResourceAsStream("/gameArt/gameDayBackground.png"));
			gameVisuals[1] = ImageIO.read(getClass().getResourceAsStream("/gameArt/ammoBox.png"));
			gameVisuals[2] = ImageIO.read(getClass().getResourceAsStream("/gameArt/snowball.png"));
			gameVisuals[3] = ImageIO.read(getClass().getResourceAsStream("/gameArt/reticle.png"));
			gameVisuals[4] = ImageIO.read(getClass().getResourceAsStream("/gameArt/scoreboard.png"));
			gameVisuals[5] = ImageIO.read(getClass().getResourceAsStream("/gameArt/sun.png"));
		}
		catch(IOException e) { e.printStackTrace(); }
	}
	
	public void draw(Graphics2D g2)
	{
		gp.setBackground(new Color(225, 246, 255));
		drawSideScroll(g2);
		
		g2.drawImage(gameVisuals[5], 10, 80, 64, 64, null);
		g2.drawImage(gameVisuals[1], 70, 420, 300, 150, null);
		g2.drawImage(gameVisuals[4], 90, 0, 260, 110, null);
		
		if(ammoLeft == 0) {}
		if(ammoLeft >= 1) { g2.drawImage(gameVisuals[2], -12, 420, 300, 150, null); }
		if(ammoLeft >= 2) { g2.drawImage(gameVisuals[2], 70, 420, 300, 150, null); }
		if(ammoLeft == 3) { g2.drawImage(gameVisuals[2], 155, 420, 300, 150, null); }
		
		if(penguinsToSpawn <= 15)
		{
			spawnPenguin(g2);
			readMouseData(g2);
			
			g2.setColor(Color.WHITE);
			g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
			g2.drawString("" + score, 130, 75);
		}
		else
		{
			gp.State = STATE.GAME_END; readMouseData(g2); 
			gp.gameEnd = new GameEnd(gp, this);
			
			leaderboards.addScore(score);
			leaderboards.updateNamesAndScores();
		}
	}

	public void spawnPenguin(Graphics2D g2) {
		
		if(spawnTickCount == spawnInterval && penguinCounter < 3)
		{
			if((int)((Math.random() * 9) + 1) >= 8)
			{ penguinsOnScreen[penguinCounter] = new SpecialPenguin(gp); }
			else
			{ penguinsOnScreen[penguinCounter] = new Penguin(gp); }
			penguinCounter++;
			
			spawnTickCount = 0;
			spawnInterval = (int)(Math.random() * 120) + 30;
			
			penguinsToSpawn++;
		}
		
		else if(penguinCounter >= 3)
		{ spawnTickCount = 0; }
		
		else
		{ spawnTickCount++; }
		
		if(penguinsOnScreen[0] != null && penguinsOnScreen[0].isVisible()) { penguinsOnScreen[0].draw(g2); }
		if(penguinsOnScreen[1] != null && penguinsOnScreen[1].isVisible()) { penguinsOnScreen[1].draw(g2); }
		if(penguinsOnScreen[2] != null && penguinsOnScreen[2].isVisible()) { penguinsOnScreen[2].draw(g2); }
		
		if(penguinsOnScreen[0] != null && !penguinsOnScreen[0].isVisible() && // IF ALL PENGUINS ARE
		   penguinsOnScreen[0] != null && !penguinsOnScreen[1].isVisible() && // OFF THE SCREEN, THE COUNTER
		   penguinsOnScreen[0] != null && !penguinsOnScreen[2].isVisible() )  // CAN BE RESET.
		{ penguinCounter = 0; }
	}

	public void drawSideScroll(Graphics2D g2) {
		
		if(sideScrollX > -1344)
		{ g2.drawImage(gameVisuals[0], sideScrollX, 0, 1344, 578, null); }
		
		if(sideScrollX < -1344 + gp.screenWidth)
		{
			g2.drawImage(gameVisuals[0], sideScrollX + 1344, 0, 1344, 578, null);
			if(sideScrollX < -1344)
			{ sideScrollX = 0; }
		}
		sideScrollX--;
		
	}
	
	public void readMouseData(Graphics2D g2)
	{
		reticle.draw(g2);
		
		gp.addMouseListener(new MouseAdapter()
		{
			public void mouseReleased(MouseEvent e2)
			{
				if(gp.State == STATE.GAME && ammoLeft > 0 && shotTaken == false)
				{
					int[] reticleBounds = reticle.getBounds();
					
					checkShot(penguinsOnScreen[0], reticleBounds);
					checkShot(penguinsOnScreen[1], reticleBounds);
					checkShot(penguinsOnScreen[2], reticleBounds);
					
					hasShotPenguin(penguinsOnScreen);
				}
				else
				{
					gp.removeMouseListener(this);
				}
			}
		});
		
		
		if(shotTaken == true) 
		{ 
			clickBuffer++;
			reticle.reload();
			if(clickBuffer == 30)
			{
				reticle.refresh();
				shotTaken = false;
				clickBuffer = 0; 
			} 
		}
		
		if(ammoLeft == 0)
		{
			reload++;
			if(reload == 180)
			{
				ammoLeft = 3;
				reload = 0;
			}
		}
	}
	
	public void checkShot(Penguin penguin, int[] reticleBounds) 
	{
		if((penguin != null) && (penguin.isVisible()) && !penguin.getCompromised())
		{
			int[] penguinBounds = penguin.getBounds();
			
			if(reticleBounds[0] >= penguinBounds[0] && 
			   reticleBounds[0] + reticleBounds[2] <= penguinBounds[0] + penguinBounds[2] &&
			   reticleBounds[1] >= penguinBounds[1] && 
			   reticleBounds[1] + reticleBounds[3] <= penguinBounds[1] + penguinBounds[3] && 
			   penguin.getCanBeShot())		
			
			{
				if(penguin.getClass().toString().contains("SpecialPenguin"))
				{ score += 300; specialPenguinsHit++; }
				else
				{ score += 100; regPenguinsHit++;  }
				
				for(int i = 0; i < penguinsOnScreen.length; i++)
				{ 
					if(penguin.equals(penguinsOnScreen[i])) 
					{ penguinsOnScreen[i].setCompromised(true); } 
				}
			}
			
			shotTaken = true;
		}	
	}
	
	public void hasShotPenguin(Penguin[] penguins)
	{
		boolean anyCompromised = false;
		
		for(int i = 0; i < penguins.length; i++)
		{
			if(penguins[i] != null && penguins[i].getCompromised())
			{ 
				anyCompromised = true; 
			}
		}
		
		if(!anyCompromised) 
		{
			score -= 100;
			ammoLeft--;  
			shotsMissed++; 
		}
		
		for(int i = 0; i < penguins.length; i++)
		{
			if(penguins[i] != null)
			{ penguins[i].setCompromised(false); }
		}
	}
}