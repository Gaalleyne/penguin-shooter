package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements Runnable
{

	private static final long serialVersionUID = 1L;
	public final int originalTileSize = 16;
	final int scale = 2;
	public final int tileSize = originalTileSize * scale;
	
	public final int maxScreenRow = 18;
	public final int maxScreenCol = 14;
	public final int screenHeight = maxScreenRow * tileSize;
	public final int screenWidth = maxScreenCol * tileSize;
	
	final int FPS = 60;
	int countdown = 0;;
	
	Menu menu;
	GameIntro gameIntro;
	GameLoop gameLoop;
	GameEnd gameEnd;
	Leaderboards leaderboards;
	
	Thread game_thread;
	MouseAdapter endMouse;
	KeyHandler kH;
	
	public enum STATE
	{
		MENU,
		LEADERBOARDS,
		GAME_START,
		GAME,
		GAME_END,
	}
	
	public STATE State = STATE.MENU;
	
	public GamePanel() {
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setDoubleBuffered(true);
		this.setFocusable(true);
		
		menu = new Menu(this);
		
		kH = new KeyHandler();
		this.addKeyListener(kH);
	}
	
	public void startGameThread()
	{
		game_thread = new Thread(this);
		game_thread.start();
	}
	
	@Override
	public void run() {

		double drawInterval = 1000000000 / FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		while(game_thread != null)
		{
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			
			lastTime = currentTime;
			
			if(delta >= 1)
			{
				repaint();
				
				delta--;
			}
		}
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		if(State == STATE.MENU)
		{
			this.setBackground(new Color(225, 246, 255));
			menu.draw(g2);
		}
		else if(State == STATE.GAME_START)
		{	
			gameIntro.draw(g2);
			if(kH.nameEntered) { countdown++; }
		}
		else if(State == STATE.GAME)
		{
			gameLoop.draw(g2);
		}
		else if(State == STATE.GAME_END)
		{				
			gameEnd.draw(g2);
			countdown++;
		}
		else
		{
			leaderboards.draw(g2);
			countdown++;
		}
	}
}
