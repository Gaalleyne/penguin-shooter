package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import main.GamePanel.STATE;

public class Leaderboards {
	
	GamePanel gp;
	
	ArrayList<String> names;
	ArrayList<Integer> scores;
	
	ArrayList<String> topThreeNames;
	ArrayList<Integer> topThreeScores;
	
	public Leaderboards() 
	{
		names = new ArrayList<String>();
		scores = new ArrayList<Integer>();
	}
	
	public Leaderboards(GamePanel gp) 
	{
		this.gp = gp;
		
		names = new ArrayList<String>();
		scores = new ArrayList<Integer>();
		
		topThreeNames = new ArrayList<String>();
		topThreeScores = new ArrayList<Integer>();
		
		getNamesAndScores();
		getRankings();

	}

	public void draw(Graphics2D g2)
	{
		gp.setBackground(Color.BLACK);
		g2.setColor(Color.WHITE);
		g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 55));
		
		if(gp.countdown > 60 && topThreeNames.size() >= 1 && topThreeScores.size() >= 0) 
		{ g2.drawString("#1. " + topThreeNames.get(0) + " - " + topThreeScores.get(0), 5, 100); }
		
		if(gp.countdown > 120 && topThreeNames.size() >= 2 && topThreeScores.size() >= 0) 
		{ g2.drawString("#2. " + topThreeNames.get(1) + " - " + topThreeScores.get(1), 5, 160); }
		
		if(gp.countdown > 180 && topThreeNames.size() >= 3 && topThreeScores.size() >= 0)
		{ g2.drawString("#3. " + topThreeNames.get(2) + " - " + topThreeScores.get(2), 5, 220); }
		
		if(gp.countdown > 240) 
		{ 
			g2.setFont(new Font("Bodoni MT Poster Compressed", Font.BOLD, 95));
			g2.drawString("MENU", 125, 525); 
		}
		
		gp.addMouseListener(gp.endMouse = new MouseAdapter()
		{
			public void mouseReleased(MouseEvent e2)
			{
				if(gp.State == STATE.LEADERBOARDS && gp.countdown > 240) 
				{ gp.State = STATE.MENU; gp.countdown = 0; }
			}
		});
	}
	
	public void getNamesAndScores() 
	{	
		FileInputStream nameFile;
		FileInputStream scoreFile;
		
		Scanner readNames;
		Scanner readScores;
		
		try
		{
			nameFile = new FileInputStream("gameNames.txt");
			scoreFile = new FileInputStream("gameScores.txt");
			
			readNames = new Scanner(nameFile);
			readScores = new Scanner(scoreFile);
			
			while(readNames.hasNextLine() && readScores.hasNextLine())
			{
				names.add(readNames.nextLine());
				scores.add( Integer.parseInt(readScores.nextLine()) );
			}
			
			readNames.close();
			readScores.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public void updateNamesAndScores() {
		FileOutputStream nameFile;
		FileOutputStream scoreFile;
		
		PrintWriter writeToNames;
		PrintWriter writeToScores;
		
		try
		{
			nameFile = new FileOutputStream("gameNames.txt", true);
			scoreFile = new FileOutputStream("gameScores.txt", true);
			
			writeToNames = new PrintWriter(nameFile);
			writeToScores = new PrintWriter(scoreFile);
			
			for(String name : names)
			{ writeToNames.write(name + "\n"); }
			
			for(int score : scores)
			{ writeToScores.write("" + score + "\n"); }
			
			writeToNames.close();
			writeToScores.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public void getRankings() 
	{
		int place = 0;
		while(topThreeScores.size() < 3 && scores.size() != 0)
		{
			topThreeScores.add(Integer.MIN_VALUE);
			topThreeNames.add("");
			
			for(int i = 0; i < scores.size(); i++)
			{
				if(scores.get(i) > topThreeScores.get(place))
				{
					topThreeScores.set(place, scores.get(i));
					topThreeNames.set(place, names.get(i));
				}
			}
			
			int placeToRemove = scores.indexOf(topThreeScores.get(place));
			scores.remove(placeToRemove);
			names.remove(placeToRemove);
			
			place++;
			
			if(scores.size() == 0) { break; }
		}
	}
	
	

	public ArrayList<String> getNames() { return names; }
	public void addName(String name) { names.add(name); }
	
	public ArrayList<Integer> getScores() { return scores; }
	public void addScore(int score) { scores.add(score); }

}
