package components;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MouseInfo;


public class GameButton
{
	private Image foreground;
	private Image border;
	public int width;
	public int height;
	public int x;
	public int y;
	private Font font;
	private String text;
	
	private int mouseX;
	private int mouseY;
	
	public GameButton(Image foreground, Image border, int width, int height, 
													  int x, int y, Graphics2D g2, String text, Font font) 
	{
		this.foreground = foreground;
		this.border = border;
		this.width = width;
		this.height = height;
		this.x = x;
		this.y = y;
		this.text = text;
		this.font = font;
	}

	public void drawButton(Graphics2D g2, int fontX, int fontY) 
	{
		g2.drawImage(border, x-12, y-12, width + 25, height + 25, null);
		g2.drawImage(foreground, x-3, y-3, width+7, height+7, null);
		
		g2.setFont(font);
		g2.drawString(text, fontX, fontY);
	}
	
	public Boolean mouseIsOver()
	{
		mouseX = (int)MouseInfo.getPointerInfo().getLocation().getX() - 407;
		mouseY = (int)MouseInfo.getPointerInfo().getLocation().getY() - 54;
		
		if((mouseX >= this.x - 12) && (mouseX <= this.width + this.x + 15) &&
		   (mouseY >= this.y - 12) && (mouseY <= this.height + this.y + 15))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public void highlightBtn(Graphics2D g2) 
	{
		g2.setColor(Color.YELLOW);
		g2.drawRect(x-13, y-12, width+26, height+25);
	}
	
}
