package entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MouseInfo;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class Reticle {

	GamePanel gp;
	Image reticle;
	int mouseX;
	int mouseY;
	
	public Reticle(GamePanel gp) {
		try 
		{ 
			reticle = ImageIO.read(getClass().getResourceAsStream("/gameArt/reticle.png"));
		} 
		catch (IOException e) 
		{ e.printStackTrace(); }
	}
	
	public void draw(Graphics2D g2)
	{
		mouseX = (int)MouseInfo.getPointerInfo().getLocation().getX() - 408 - 20;
		mouseY = (int)MouseInfo.getPointerInfo().getLocation().getY() - 55 - 20;
		
		g2.drawImage(reticle, mouseX, mouseY, 48, 48, null);
		
//		g2.setColor(Color.RED);
//		g2.drawRect(mouseX + 16, mouseY + 16, 16, 16);
	}
	
	public int[] getBounds() { return new int[] {mouseX + 16, mouseY + 16, 16, 16}; }

	public void reload() 
	{
		try 
		{
			reticle = ImageIO.read(getClass().getResourceAsStream("/gameArt/reticleReload.png"));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public void refresh() 
	{
		try 
		{
			reticle = ImageIO.read(getClass().getResourceAsStream("/gameArt/reticle.png"));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

}
