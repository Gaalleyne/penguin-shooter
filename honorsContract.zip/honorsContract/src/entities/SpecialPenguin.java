package entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class SpecialPenguin extends Penguin {

	int warningCounter;
	Image warningSprite;
	
	public SpecialPenguin(GamePanel gp) 
	{
		super(gp);
		try 
		{
			penguinSprite1 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_1.png"));
			penguinSprite2 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_2.png"));
			penguinSprite3 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_3.png"));
			warningSprite = ImageIO.read(getClass().getResourceAsStream("/gameArt/spec_penguin_warning.png"));
			
			swimRate = 11;
			screenY = (int)(Math.random() * 30) + 300;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		warningCounter = 0;
	}
	
	@Override
	public void draw(Graphics2D g2) 
	{
		if(warningCounter >= 120)
		{
			screenX += swimRate;
			
			if(spriteCounter == 1) { g2.drawImage(penguinSprite1, screenX, screenY, 150, 100, null); }
			else if(spriteCounter == 2) { g2.drawImage(penguinSprite2, screenX, screenY, 150, 100, null); }
			else  { g2.drawImage(penguinSprite3, screenX, screenY, 150, 100, null); spriteCounter = 0; }
			
			if(spriteClock == 1) { spriteCounter++; spriteClock = 0; }
			else { spriteClock++; }
			
//			g2.setColor(Color.RED);
//			g2.drawRect(screenX, screenY, 150, 100);
			
		}
		else if( (warningCounter >= 0 && warningCounter <= 20) ||
				 (warningCounter >= 40 && warningCounter <= 60) ||
				 (warningCounter >= 80 && warningCounter <= 100)   )
		{ g2.drawImage(warningSprite, 10, screenY, 32, 64, null); warningCounter++;}
		else
		{ warningCounter++; }
	}
	
	@Override
	public void setCompromised(boolean compromised) 
	{ 
		if(this.compromised)
		{
			try 
			{
				penguinSprite1 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_hit1.png"));
				penguinSprite2 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_hit2.png"));
				penguinSprite3 = ImageIO.read(getClass().getResourceAsStream("/sprites/spec_penguin_fwd_hit3.png"));
				canBeShot = false;	
			} 
			catch (IOException e) 
			{ e.printStackTrace(); }
		}
		
		this.compromised = compromised;
		
	}

}
