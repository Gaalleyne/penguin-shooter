package entities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class Penguin {

	GamePanel gp;
	Image penguinSprite1;
	Image penguinSprite2;
	Image penguinSprite3;
	int swimRate;
	int screenX;
	int screenY;
	int spriteCounter;
	int spriteClock;
	
	int ySeed;
	int yClock;
	boolean cooldown;
	
	boolean isVisible;
	boolean compromised;
	boolean canBeShot;
	
	public Penguin(GamePanel gp) {
		try 
		{ 
			penguinSprite1 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_1.png"));
			penguinSprite2 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_2.png"));
			penguinSprite3 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_3.png"));
			spriteCounter = 1;
			swimRate = 4;
			spriteClock = 0;
			yClock = 0;
			
			screenX = -120;
			screenY = 320 + (int)(swimRate * ((Math.random() * 2) - 1)); yClock = 0;;
			
			isVisible = false;
			compromised = false;
			canBeShot = true;
		} 
		catch (IOException e) 
		{ e.printStackTrace(); }
	}

	public void draw(Graphics2D g2) {
		
		getNewCoords();
		
		if(spriteCounter == 1) { g2.drawImage(penguinSprite1, screenX, screenY, 150, 100, null); }
		else if(spriteCounter == 2) { g2.drawImage(penguinSprite2, screenX, screenY, 150, 100, null); }
		else  { g2.drawImage(penguinSprite3, screenX, screenY, 150, 100, null); spriteCounter = 0; }
		
		if(spriteClock == 1) { spriteCounter++; spriteClock = 0; }
		else { spriteClock++; }
		
//		g2.setColor(Color.RED);
//		g2.drawRect(screenX, screenY, 150, 100);
	}

	public void getNewCoords() {
		
		screenX += swimRate;
		
		if((int)(Math.random() + 0.5) == 1 && !cooldown) 
		{ 
			ySeed = (int)(swimRate * ((Math.random() * 2) - 1)); 
			yClock = 0; 
			cooldown = true;
		}
		else if(cooldown)
		{ 
			if(yClock == 30)
			{cooldown = false;} 
			yClock++; 
		}
		
		if((screenY + ySeed) > 230 && (screenY + ySeed) < 330) 
		{ screenY += ySeed; }
	}

	public boolean isVisible() {
		if(screenX >= -120 && screenX <= 500)
			return true;
		else
			return false;
	}
	
	public void setVisible(Boolean isVisible) {
		// TODO Auto-generated method stub
		this.isVisible = isVisible;
	}
	
	public int[] getBounds()
	{
		return new int[] {screenX, screenY, 150, 100};
	}
	
	public boolean getCompromised() { return compromised; }
	public void setCompromised(boolean compromised) 
	{ 
		if(this.compromised)
		{
			try 
			{
				penguinSprite1 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_hit1.png"));
				penguinSprite2 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_hit2.png"));
				penguinSprite3 = ImageIO.read(getClass().getResourceAsStream("/sprites/reg_penguin_fwd_hit3.png"));
				canBeShot = false;	
			} 
			catch (IOException e) 
			{ e.printStackTrace(); }
		}
		
		this.compromised = compromised;
	}
	
	public boolean getCanBeShot() { return canBeShot; }
	public void setCanBeShot(boolean canBeShot) { this.canBeShot = canBeShot; }
}